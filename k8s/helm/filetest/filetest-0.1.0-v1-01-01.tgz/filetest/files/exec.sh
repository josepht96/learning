newman run filetest.postman_collection.json -e env.postman_environment.json --env-var key=value &&
newman run filetest.postman_collection.json -e env.postman_environment.json